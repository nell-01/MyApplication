package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BudgetActivity extends AppCompatActivity {

    EditText income1, income2, otherIncome, budget;
    EditText billName, dueDate, amount, paid;
    TextView totalIncome, totalExpenses, summaryIncome, summaryExpenses, summaryDifference;
    TextView billTotal;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget);

        income1 = findViewById(R.id.income1);
        income2 = findViewById(R.id.income2);
        otherIncome = findViewById(R.id.otherIncome);
        budget = findViewById(R.id.budget);

        billName = findViewById(R.id.billName);
        dueDate = findViewById(R.id.dueDate);
        amount = findViewById(R.id.amount);
        paid = findViewById(R.id.paid);

        totalIncome = findViewById(R.id.totalIncome);
        totalExpenses = findViewById(R.id.totalExpenses);
        summaryIncome = findViewById(R.id.summaryIncome);
        summaryExpenses = findViewById(R.id.summaryExpenses);
        summaryDifference = findViewById(R.id.summaryDifference);
        billTotal = findViewById(R.id.billTotal);

        TextWatcher watcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                calculateTotals();
            }
        };

        income1.addTextChangedListener(watcher);
        income2.addTextChangedListener(watcher);
        otherIncome.addTextChangedListener(watcher);
        budget.addTextChangedListener(watcher);
        amount.addTextChangedListener(watcher);
        paid.addTextChangedListener(watcher);
    }

    private void calculateTotals() {
        double i1 = parseDouble(income1.getText().toString());
        double i2 = parseDouble(income2.getText().toString());
        double other = parseDouble(otherIncome.getText().toString());
        double total = i1 + i2 + other;

        double exp = parseDouble(budget.getText().toString());

        totalIncome.setText("Total Income: ₱" + total);
        totalExpenses.setText("Total Expenses: ₱" + exp);
        summaryIncome.setText("Total Income: ₱" + total);
        summaryExpenses.setText("Total Expenses: ₱" + exp);
        summaryDifference.setText("Difference: ₱" + (total - exp));

        double billAmt = parseDouble(amount.getText().toString());
        double billPaid = parseDouble(paid.getText().toString());
        double remaining = billAmt - billPaid;
        billTotal.setText("Total Remaining: ₱" + remaining);
    }

    private double parseDouble(String value) {
        try {
            return Double.parseDouble(value);
        } catch (Exception e) {
            return 0.0;
        }
    }
}
